//
// Created by Álvaro Castro González on 20/2/24.
// example of using a shared memory object
// WARNING: in a multiprocess system, accessing SM objects must be controlled to avoid race conditions
//

#include <stdio.h>      // for printf(), sprintf()
#include <sys/mman.h>   // for shm_open
#include <sys/fcntl.h>  // for O_RDONLY
#include <unistd.h>     // for ftruncate()

int main ()
{
    /* the size (in bytes) of shared memory object */
    const int SHARED_SEGMENT_SIZE = 4096;

    /* name of the shared memory object */
    const char* name = "/my_shared_mem";
    const char* message = "Hi all!";

    /* open the shared memory object */
    // shm_fd -> shared memory file descriptor
    int shm_fd = shm_open(name, O_CREAT | O_RDWR, 0666);

    /* change the size of the SM object */
    ftruncate(shm_fd, SHARED_SEGMENT_SIZE);

    /* memory map the shared memory object */
    // ptr -> pointer to shared memory objetc
    void* ptr = mmap(0, SHARED_SEGMENT_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);


    /* write to the shared memory object */
    sprintf((char*)ptr, "%s", message);

    /* read from the shared memory object */
    printf("%s", (char*)ptr);

    /* memory unmap the shared memory object */
    munmap(ptr, SHARED_SEGMENT_SIZE);

    /* remove the shared memory object */
    shm_unlink(name);
    return 0;

}