#include <stdio.h>
#include <mqueue.h>
#include <unistd.h>
#include <string.h>

#define NUMBER_OF_MESSAGES 5

void writer_mq(mqd_t mqd) {
    struct mq_attr attr;
    char str[NUMBER_OF_MESSAGES][80] = {"A", "posix", "message", "queue", "example"};

    printf("Writing messages to the POSIX message queue\n\n");

    for(int i = 0; i < NUMBER_OF_MESSAGES; i++) {
        // Write to the POSIX message queue
        mq_send(mqd, str[i], strlen(str[i]), 0);
        printf("The message written to the queue: %s\n", str[i]);

        // Read the number of messages in the queue
        mq_getattr(mqd, &attr);
        printf("Number of messages in the queue: %d\n", attr.mq_curmsgs);
    }
}

void reader_mq(mqd_t mqd) {
    struct mq_attr attr;

    printf("Reading messages from the POSIX message queue\n\n");

    for(int i = 0; i < NUMBER_OF_MESSAGES; i++) {
        char buff[8192] = {'\0'};

        // Read from the POSIX message queue
        mq_receive(mqd, buff, attr.mq_msgsize, NULL);
        printf("The message read from the queue: %s\n", buff);

        // Read the number of messages in the queue
        mq_getattr(mqd, &attr);
        printf("Number of messages in the queue: %d\n", attr.mq_curmsgs);
    }
}

int main() {
    mqd_t mqd;

    // Open the POSIX message queue
    mqd = mq_open("/mqp", O_RDWR | O_CREAT, S_IRUSR | S_IWUSR, NULL);

    // Write messages to the queue
    writer_mq(mqd);

    printf("\nPress enter to continue");
    getchar();

    // Read messages from the queue
    reader_mq(mqd);

    // Close the message queue
    mq_close(mqd);
    // Delete the corresponding file from the filesystem
    mq_unlink("/mqp");
}