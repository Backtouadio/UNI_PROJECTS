//
// Created by Álvaro Castro González on 20/2/24.
//
#include <stdio.h>
#include <stdlib.h>     // for exit()
#include <pthread.h>

#define NUM_THREADS 10
void *thread_function(void *);

pthread_mutex_t my_mutex = PTHREAD_MUTEX_INITIALIZER;
int  counter = 0;

int main()
{
    pthread_t thread_id[NUM_THREADS];
    int i, rc;

    for(i=0; i < NUM_THREADS; i++)
    {
        rc=pthread_create( &thread_id[i], NULL, thread_function, NULL );
        if(rc != 0)
        {
            printf("pthread_create fail; return code from pthread_create() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    for(i=0; i < NUM_THREADS; i++)
    {
        rc=pthread_join( thread_id[i], NULL);
        if (rc!=0)
        {
            printf("pthread_join fail; return code from pthread_join() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    /* Now that all threads are complete I can print the final result.     */
    /* Without the join I could be printing a value before all the threads */
    /* have been completed.                                                */

    printf("Final counter value: %d\n", counter);

    // pthread_mutex_lock(&my_mutex); // uncomment this line and see what happens
    rc = pthread_mutex_destroy(&my_mutex); // fails if my_mutex is locked. After this call, my_mutex may not be used as a mutex anymore, unless it is initialized again.
    if (rc!=0) {
        printf("pthread_mutex_destroy fail; return code from pthread_mutex_destroy() is %d\n", rc);
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}

void* thread_function(void *dummyPtr)
{
    pthread_mutex_lock(&my_mutex);
    counter++;
    printf("Thread number %ld -> counter=%d\n", (long int) pthread_self(), counter);
    pthread_mutex_unlock(&my_mutex); // try to move this line just after counter is incremented, what changes in the output? why?

    return NULL;
}