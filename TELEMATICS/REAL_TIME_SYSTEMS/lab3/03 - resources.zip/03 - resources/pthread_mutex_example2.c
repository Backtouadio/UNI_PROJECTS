//
// Created by Álvaro Castro González on 20/2/24.
// We are forcing a deadlock
//
#include <stdio.h>
#include <stdlib.h>     // for exit()
#include <pthread.h>
#include <unistd.h>     // for sleep()
#include <errno.h>      // for errno

pthread_mutex_t mutex1;
pthread_mutex_t mutex2;

void *thread_function1(void *); // locks mutex1 and then mutex2
void *thread_function2(void *); // locks mutex2 and then mutex1

int main()
{
    pthread_t thread_id1, thread_id2;
    int rc;

    // mutex initialization
    if (pthread_mutex_init(&mutex1, NULL) || pthread_mutex_init(&mutex2, NULL)) {
        perror("pthread_mutex_init() error");
        exit(2);
    }

    // creation of the 1st thread
    rc=pthread_create( &thread_id1, NULL, thread_function1, NULL );
    if(rc != 0)
    {
        printf("pthread_create fail in the 1st thread; return code from pthread_create() is %d\n", rc);
        exit(EXIT_FAILURE);
    }
    // creation of the 2nd thread
    rc=pthread_create( &thread_id2, NULL, thread_function2, NULL );
    if(rc != 0)
    {
        printf("pthread_create fail in the 2nd thread; return code from pthread_create() is %d\n", rc);
        exit(EXIT_FAILURE);
    }

    // joining both threads
    if ( (rc=pthread_join(thread_id1, NULL)) || (rc=pthread_join(thread_id2,NULL)) )
    {
        printf("pthread_join fail; return code from pthread_join() is %d\n", rc);
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}

void* thread_function1(void *dummyPtr)
{
    pthread_mutex_lock(&mutex1);
    printf("Thread 1 has locked mutex1\n");
    //sleep(1); // uncomment this line to force deadlock
    pthread_mutex_lock(&mutex2);
    printf("Thread 1 has locked mutex2\n");
    sleep(1);
    pthread_mutex_unlock(&mutex2);
    printf("Thread 1 has unlocked mutex2\n");
    pthread_mutex_unlock(&mutex1);
    printf("Thread 1 has unlocked mutex1\n");
    return NULL;
}

void* thread_function2(void *dummyPtr)
{
    pthread_mutex_lock(&mutex2);
    printf("Thread 2 has locked mutex2\n");
    pthread_mutex_lock(&mutex1);
    printf("Thread 2 has locked mutex1\n");
    sleep(2);
    pthread_mutex_unlock(&mutex1);
    printf("Thread 2 has unlocked mutex1\n");
    pthread_mutex_unlock(&mutex2);
    printf("Thread 2 has unlocked mutex2\n");
    return NULL;
}


/* Solution */
/*
void* thread_function2(void *dummyPtr)
{
    pthread_mutex_lock(&mutex2);
    printf("Thread 2 has locked mutex2\n");
    int error_number=pthread_mutex_trylock(&mutex1);
    if(error_number==0) {
        printf("Thread 2 has locked mutex1\n");
        sleep(2); // critical section
        pthread_mutex_unlock(&mutex1);
        printf("Thread 2 has unlocked mutex1\n");
    }
    else if (error_number == EBUSY) // this error indicates that the mutex is already locked
        printf("Thread 2 was denied access to mutex1. Error code is %d\n", error_number);
    else if (error_number == EINVAL) // this error indicates that the mutex is already locked
        printf("Thread 2 used an invalid mutex id to access mutex1. Error code is %d\n", error_number);
    else
        perror("Thread 2 pthread_mutex_trylock() error");

    pthread_mutex_unlock(&mutex2);
    printf("Thread 2 has unlocked mutex2\n");
    return NULL;
}
*/