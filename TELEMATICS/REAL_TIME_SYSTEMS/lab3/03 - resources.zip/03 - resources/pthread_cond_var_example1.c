//
// Created by Álvaro Castro González on 20/2/24.
// example of using a condition variable
//
#include <stdio.h>
#include <unistd.h>     // for sleep()
#include <pthread.h>

#define NUM_THREADS 3
#define TCOUNT 10
#define COUNT_LIMIT 12

pthread_mutex_t counter_mutex;        // mutex to synchronize the access to the shared counter. This mutex will be used with the cond.var.
pthread_cond_t overheat_cv;           // cond.var. to monitor when the counter reaches a certain value. Can be initialized assigning the macro PTHREAD_COND_INITIALIZER
int  counter = 0;                     // global counter shared between threads

void* inc_count(void *t);   // threaded function to increment the counter
void* watch_count(void *t); // threaded function to monitor the counter value

int main()
{
    pthread_t threads[NUM_THREADS];

    pthread_mutex_init(&counter_mutex, NULL); // initialization of mutex. NULL => default attributes
    pthread_cond_init (&overheat_cv, NULL); // initialization of cond.var. NULL => default attributes

    //creating three threads
    printf("Creating threads to increment and monitor a shared counter\n");
    pthread_create(&threads[0], NULL, watch_count, NULL);
    pthread_create(&threads[1], NULL, inc_count, NULL);
    pthread_create(&threads[2], NULL, inc_count, NULL);

    for (int i=0; i<NUM_THREADS; i++) { // Wait for all threads
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&counter_mutex);
    pthread_cond_destroy(&overheat_cv);
    printf("Counter = %d\n",counter);
    pthread_exit(NULL); // keep the process running until all threads terminate
}

void *inc_count(void *t){
    for (int i=0; i<TCOUNT; i++) {
        pthread_mutex_lock(&counter_mutex);
        counter++;
        if (counter == COUNT_LIMIT) { // it signals when the limit is reached
            pthread_cond_signal(&overheat_cv);
        }
        printf("Thread %ld increments counter to %d\n", (long int) pthread_self(), counter);
        pthread_mutex_unlock(&counter_mutex);
        sleep(1);
    }
    pthread_exit(NULL);
}

void *watch_count(void *t){
    long my_id = (long)t;
    pthread_mutex_lock(&counter_mutex);
    if (counter<COUNT_LIMIT) {
        pthread_cond_wait(&overheat_cv, &counter_mutex); // when blocked, counter_mutex is automatically and atomically unlocked
        // when the cond.var. is signaled, the block thread is woken up,
        // the counter_mutex is automatically and atomically locked again,
        // and we can safely operate with counter
        counter += 125;
    }
    printf("Thread %ld monitors and increments counter to %d\n", (long int) pthread_self(), counter);
    pthread_mutex_unlock(&counter_mutex);   // counter_mutex needs to be explicitly unlocked
    pthread_exit(NULL);
}