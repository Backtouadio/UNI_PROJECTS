//
// Created by Álvaro Castro González on 20/2/24.
// exercise of condition variables
//
#include <stdio.h>
#include <unistd.h>     // for sleep()
#include <stdlib.h>     // for exit()
#include <pthread.h>
#include <stdbool.h>

#define NUM_THREADS 10

pthread_mutex_t rsrc_lock;
pthread_cond_t rsrc_add;
unsigned int resources_available=3;

void* thread_function(void *t);

int main()
{
    pthread_mutex_init(&rsrc_lock, NULL); // initialization of mutex. NULL => default attributes
    pthread_cond_init (&rsrc_add, NULL); // initialization of cond.var. NULL => default attributes
    pthread_t thread_id[NUM_THREADS];

    //creating threads
    int i, rc;
    printf("Creating threads...\n");
    for(i=0; i < NUM_THREADS; i++)
    {
        rc=pthread_create( &thread_id[i], NULL, thread_function, NULL );
        if(rc != 0)
        {
            printf("pthread_create %d fail; return code from pthread_create() is %d\n", i, rc);
            exit(EXIT_FAILURE);
        }
    }
    //joining threads
    printf("Joining threads...\n");
    for(i=0; i < NUM_THREADS; i++)
    {
        rc=pthread_join( thread_id[i], NULL);
        if (rc!=0)
        {
            printf("pthread_join fail; return code from pthread_join() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    pthread_mutex_destroy(&rsrc_lock);
    pthread_cond_destroy(&rsrc_add);
    printf("Done with resources\n");
    //pthread_exit(NULL); // keep the process running until all threads terminate
    exit(EXIT_SUCCESS);
}

void hold_resource()
{
    pthread_mutex_lock(&rsrc_lock);
    while (resources_available < 1) {
        pthread_cond_wait(&rsrc_add, &rsrc_lock);
    }
    resources_available--;
    pthread_mutex_unlock(&rsrc_lock);
}

void release_resource()
{
    pthread_mutex_lock(&rsrc_lock);
    resources_available++;
    pthread_cond_broadcast(&rsrc_add); // all threads blocked on the condition contend again for the mutex lock
    pthread_mutex_unlock(&rsrc_lock);
}

void* thread_function(void *t){
    int rand_num = rand()%5 + 1;
    hold_resource();
    printf("Thread %ld using one resource for %d second\n", (long int) pthread_self(), rand_num);
    sleep(rand_num);
    release_resource();
    printf("Thread %ld has released one resource\n", (long int) pthread_self());
    pthread_exit(NULL);
}
