//
// Created by Álvaro Castro González on 20/2/24.
// example of using a shared memory segment
// WARNING: in a multiprocess system, accessing SM segments must be controlled to avoid race conditions
//

#include <stdio.h>      // for printf(), sprintf()
#include <stdlib.h>     // for exit()
#include <sys/shm.h>    // for shmget(), shmat(), ...
#include <sys/stat.h>   // for S_IRUSR, S_IWUSR
#include <unistd.h>     // for pause(), ftruncate()
#include <semaphore.h>
#include <sys/mman.h>   // for shm_open
#include <sys/fcntl.h>  // for O_RDONLY

#define SEM_WRITER "/sem_writer"    // semaphore for signalling that data has been writen
#define SEM_READER "/sem_reader"    // semaphore for signalling that data has been read

sem_t * sem_writer;     // global semaphore descriptor for writing
sem_t * sem_reader;     // global semaphore descriptor for reading

const int SHARED_SEGMENT_SIZE = 4096;   // the size (in bytes) of shared memory object
const char* name = "/my_shared_mem";    // name of the shared memory object
void* ptr = NULL;                       // global pointer to the shared memory object

void creating_shared_memory_object(){
    /* Allocate a shared memory segment. */

    int shm_fd = shm_open(name, O_CREAT | O_RDWR, 0666);
    if(shm_fd==-1) {
        perror("Error opening new SM object for R/W operation");
        exit(EXIT_FAILURE);
    }

    /* change the size of the SM object */
    ftruncate(shm_fd, SHARED_SEGMENT_SIZE);

    /* Memory map the shared memory object */
    ptr = mmap(0, SHARED_SEGMENT_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
}

void closing_shared_memory_object() {
    /* memory unmap the shared memory object */
    munmap(ptr, SHARED_SEGMENT_SIZE);

    /* remove the shared memory object */
    shm_unlink(name);

}

void semaphores_creation() {
    sem_writer = sem_open(SEM_WRITER, O_CREAT, 0666, 0);
    if (sem_writer == SEM_FAILED) {
        perror("Writer semaphore creation failed");
        exit(EXIT_FAILURE);
    }

    sem_reader = sem_open(SEM_READER, O_CREAT, 0666, 0);
    if (sem_reader == SEM_FAILED) {
        perror("Reader semaphore creation failed");
        exit(EXIT_FAILURE);
    }
}

void semaphores_closing() {
    if (sem_close(sem_writer) != 0 || sem_close(sem_reader) !=0 ) {
        perror("Error closing semaphores");
        exit(EXIT_FAILURE);
    }
}

int main ()
{
    // This program has to be run before the reader to create the named semaphores
    semaphores_creation();
    creating_shared_memory_object();
    if(sem_writer==NULL || sem_reader==NULL || ptr==NULL) {
        exit(EXIT_FAILURE); // just to check that the global pointers are not NULL
    }

    printf ("writer: shared memory mapped at address %p\n", ptr);
    /* Write a string to the shared memory segment. */
    sprintf (ptr, "Hello, world.");
    printf ("writer: message written -> %s\n", (char*) ptr);

    /* Signaling that data has been written */
    if (sem_post(sem_writer) == -1) {   // here we signal that data is ready
        perror("Post on writer semaphore failed");
        exit(EXIT_FAILURE);
    }

    /* waiting until the reader has completed before SM segment is removed */
    printf ("writer: waiting for readers\n");
    if (sem_wait(sem_reader) == -1) { // here we wait for the reader to signal
        perror("Wait on reader semaphore failed");
        sem_close(sem_writer);
        exit(EXIT_FAILURE);
    }

    closing_shared_memory_object();
    semaphores_closing();

    return 0;
}