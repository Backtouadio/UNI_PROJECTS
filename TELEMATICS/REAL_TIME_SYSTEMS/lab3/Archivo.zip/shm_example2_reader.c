//
// Created by Álvaro Castro González on 20/2/24.
// example of using a shared memory segment
// WARNING: in a multiprocess system, accessing SM segments must be controlled to avoid race conditions
//

#include <stdio.h>      // for printf(), sprintf()
#include <stdlib.h>     // for exit()
#include <sys/shm.h>    // for shmget(), shmat(), ...
#include <sys/stat.h>   // for S_IRUSR, S_IWUSR
#include <unistd.h>     // for pause(), ftruncate()
#include <semaphore.h>
#include <sys/mman.h>   // for shm_open
#include <sys/fcntl.h>  // for O_RDONLY

#define SEM_WRITER "/sem_writer"    // semaphore for signalling that data has been writen
#define SEM_READER "/sem_reader"    // semaphore for signalling that data has been read
sem_t * sem_writer = NULL;
sem_t * sem_reader = NULL;

const int SHARED_SEGMENT_SIZE = 4096;   // the size (in bytes) of shared memory object
const char* name = "/my_shared_mem";    // name of the shared memory object
void * ptr = NULL;                      // global pointer to shared memory object

void openning_existing_semaphores(){
    sem_writer = sem_open(SEM_WRITER, 0);
    if (sem_writer == SEM_FAILED) {
        perror("Writer semaphore creation failed");
        exit(EXIT_FAILURE);
    }

    sem_reader = sem_open(SEM_READER, 0);
    if (sem_reader == SEM_FAILED) {
        perror("Reader semaphore creation failed");
        exit(EXIT_FAILURE);
    }
}

void semaphores_closing() {
    if (sem_close(sem_writer) != 0 || sem_close(sem_reader) !=0 ) {
        perror("Error closing semaphores");
        exit(EXIT_FAILURE);
    }
}

void opening_existing_shared_memory () {
    /* Open the shared memory object */
    int shm_fd = shm_open(name, 0);
    if(shm_fd==-1) {
        perror("Error opening new SM object for R operation");
        exit(EXIT_FAILURE);
    }

    /* change the size of the SM object */
    ftruncate(shm_fd, SHARED_SEGMENT_SIZE);

    /* Memory map the shared memory object */
    ptr = mmap(0, SHARED_SEGMENT_SIZE, PROT_READ, MAP_SHARED, shm_fd, 0); // only for reading
}

void closing_shared_memory() {
    /* memory unmap the shared memory object */
    munmap(ptr, SHARED_SEGMENT_SIZE);

    /* remove the shared memory object */
    shm_unlink(name);
}

int main ()
{
    // This program has to be run after the writer that creates the named semaphores

    /* Opening already existing named semaphores */
    openning_existing_semaphores();
    opening_existing_shared_memory();
    if (sem_writer==NULL || sem_reader==NULL || ptr==NULL) exit(EXIT_FAILURE); // just to check that the pointer is not NULL

    printf ("reader: waiting for message\n");
    if (sem_wait(sem_writer) == -1) {
        perror("Wait on writer semaphore failed");
        semaphores_closing();
        exit(EXIT_FAILURE);
    }
    
    printf ("reader: shared memory mapped at address %p\n", ptr);

    /* Print out the string from shared memory. */
    printf ("reader: message received -> %s\n", (char*)ptr);

    closing_shared_memory(); // we don't need the shared memory object anymore

    /* Signaling that the reader does not need the SM segment anymore */
    if (sem_post(sem_reader) == -1) {   // here we signal that reader is done
        perror("Post on reader semaphore failed");
        semaphores_closing();
        exit(EXIT_FAILURE);
    }

    semaphores_closing();
    return 0;
}