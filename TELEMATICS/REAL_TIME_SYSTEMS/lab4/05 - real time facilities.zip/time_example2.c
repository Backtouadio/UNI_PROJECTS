//
// Created by Álvaro Castro González on 2/4/24.
// example of using time data
//

#include <stdio.h>      // for printf(), sprintf()
#include <time.h>       // for time_t, time()

int main ()
{
    clock_t start, end;
    double cpu_time_used;

    start = clock();
    printf("clocks per second = %d\n", CLOCKS_PER_SEC);
    end = clock();
    cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;

    printf("CPU time used to print a message is %f seconds\n",cpu_time_used);
    return 0;
}