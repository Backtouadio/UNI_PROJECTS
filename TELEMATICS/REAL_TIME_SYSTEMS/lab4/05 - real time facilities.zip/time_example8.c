//#include <sys/time.h>
#include <signal.h>     // for sigaction()
#include <time.h>
#include <stdlib.h>     // for exit()
#include <stdint.h>     // for uint64_t
#include <string.h>     // for memset()
#include <stdio.h>      // for printf()
#include <unistd.h>     // for pause()

timer_t timer;  // timer id

/* signal handler */
void signal_handler(int signo, siginfo_t *info, void *extra)
{
    void *ptr_val = info->si_value.sival_ptr;
    int int_val = info->si_value.sival_int;
    printf("Signal %d, value %d  received\n", signo, int_val);
    //exit(0); <-- if we exit here the program terminates after the first shot of the timer
}

void start_periodic_timer(uint64_t offs, int period) // offs and period are in microseconds
{
    // Declare the variable names for your itimerspec data structure and specify interval and expiration values.
    struct itimerspec time_spec_timer;    // time specifications of the timer
    time_spec_timer.it_value.tv_sec     = offs    / 1000000;            // seconds
    time_spec_timer.it_value.tv_nsec    = (offs   % 1000000) * 1000;    // nanoseconds
    time_spec_timer.it_interval.tv_sec  = period  / 1000000;            // seconds
    time_spec_timer.it_interval.tv_nsec = (period % 1000000) * 1000;    // nanoseconds

    // Establish a sigevent structure containing the signal to be passed to the process on timer expiration
    struct sigevent sigev_timer_expiration;  // specifies how to notify when the timer expires
    memset(&sigev_timer_expiration, 0, sizeof(struct sigevent)); // initialize sig_timer_expirtion fields to 0
    sigev_timer_expiration.sigev_notify = SIGEV_SIGNAL;
    sigev_timer_expiration.sigev_signo = SIGALRM; // we use signal SIGALRM

    // Set up a signal handler to catch the signal when the timer expires.
    struct sigaction action;
    action.sa_flags = SA_SIGINFO;           // the handler function is pointed to by the sa_sigaction
    action.sa_sigaction = signal_handler;   // signal handler function
    if (sigaction(SIGALRM, &action, NULL) == -1) {
        perror("error sigaction");
        exit(EXIT_FAILURE);
    }

    // Call the timer_create function to create a timer and associate it with the specified clock. Specify a signal to be delivered when the timer expires.
    int res = timer_create(CLOCK_MONOTONIC, &sigev_timer_expiration, &timer);
    if (res < 0) {
        perror("error timer_create");
    	exit(EXIT_FAILURE);
    }

    // Call the timer_settime function to initialize and activate the timer as either an absolute or relative timer.
    res = timer_settime(timer, 0 /*TIMER_ABSTIME*/, &time_spec_timer, NULL);
    if (res < 0) {
        perror("error timer_settime");
        exit(EXIT_FAILURE);
    }
}



int main()
{
    int res;

    start_periodic_timer(2000000, 1000000); // offs and period are in microseconds

    for(;;) pause(); // Loop forever,
    // for loop is needed because pause wakes up with every expiration signal from the timer. Remove for and test it.

    timer_delete(timer);    // this line will never be called
    return 0;
}
