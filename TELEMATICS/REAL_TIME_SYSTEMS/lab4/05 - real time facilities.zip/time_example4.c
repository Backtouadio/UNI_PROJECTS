//
// This program calculates the monotonic time
// and the process CPU time for a 1-second sleep
// operation.
//

#include <stdio.h>	// for printf()
#include <stdint.h>	// for uint64 definition()
#include <stdlib.h>	// for exit()
#include <time.h>	// for clock_gettime()
#include <unistd.h> // for sleep()

#define NANOSECONDS_PER_SECOND 1000000000L

int main(int argc, char **argv)
{
    uint64_t diff;
    struct timespec start, end;
    int i;

    /* measure monotonic time */
    clock_gettime(CLOCK_MONOTONIC, &start);	/* mark start time */
    sleep(1);	/* do stuff */
    clock_gettime(CLOCK_MONOTONIC, &end);	/* mark the end time */

    diff = NANOSECONDS_PER_SECOND * (end.tv_sec - start.tv_sec) + end.tv_nsec - start.tv_nsec;
    printf("elapsed time = %llu nanoseconds\n", (long long unsigned int) diff);

    /* now re-do this and measure CPU time */
    /* the time spent sleeping will not count (but there is a bit of overhead */
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &start);	/* mark start time */
    sleep(1);	/* do stuff */
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &end);		/* mark the end time */

    diff = NANOSECONDS_PER_SECOND * (end.tv_sec - start.tv_sec) + end.tv_nsec - start.tv_nsec;
    printf("elapsed process CPU time = %llu nanoseconds\n", (long long unsigned int) diff);

    exit(0);
}