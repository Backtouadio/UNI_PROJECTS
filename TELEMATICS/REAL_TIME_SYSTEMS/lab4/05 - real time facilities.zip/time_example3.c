//
// This program calculates the time required to
// execute the program specified as its first argument.
// The time is printed in seconds, on standard out.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define NANOSECONDS_PER_SECOND  1000000000L;

int main( int argc, char** argv )
{
    struct timespec start, stop, resolution;

    /* Printing out the clock resolutions */
    if (clock_getres( CLOCK_REALTIME, &resolution) == -1 ) {
        perror( "clock realtime get resolution" );
        exit( EXIT_FAILURE );
    }
    printf("CLOCK_REALTIME resolution is %ld micro seconds.\n",resolution.tv_nsec / 1000 );
    if (clock_getres( CLOCK_MONOTONIC, &resolution) == -1 ) {
        perror( "clock monotonic get resolution" );
        exit( EXIT_FAILURE );
    }
    printf("CLOCK_MONOTONIC resolution is %ld micro seconds.\n",resolution.tv_nsec / 1000 );

    /* Getting the start time */
    if( clock_gettime( CLOCK_MONOTONIC, &start) == -1 )
    {
        perror( "clock start gettime" );
        return EXIT_FAILURE;
    }

    /* execute the command which is specified as its first argument */
    if (argc!=2) {
        printf("Error: invalid number of arguments\n");
        return EXIT_FAILURE;
    }
    system( argv[1] );

    /* Getting the stop time */
    if( clock_gettime( CLOCK_MONOTONIC, &stop) == -1 )
    {
        perror( "clock stop gettime" );
        return EXIT_FAILURE;
    }

    /* calculating the elapsed time required for executing */
    double elapsed = ( stop.tv_sec - start.tv_sec )
            + (double)( stop.tv_nsec - start.tv_nsec ) / (double) NANOSECONDS_PER_SECOND;
    printf( "%lf seconds\n", elapsed );

    return EXIT_SUCCESS;
}