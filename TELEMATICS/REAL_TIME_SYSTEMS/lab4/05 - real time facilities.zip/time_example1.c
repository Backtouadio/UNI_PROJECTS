//
// Created by Álvaro Castro González on 2/4/24.
// example of using time data
//

#include <stdio.h>      // for printf(), sprintf()
#include <time.h>       // for time_t, time()

int main ()
{
    time_t     now;
    struct tm *ts;
    char       buf[80];

    /* Get time of the day */
    now = time(0);

    /* Formatting and printing time , "ddd yyyy-mm-dd hh:mm:ss zzz" */
    ts = localtime(&now); // time information after adjusting for the current time zone and Daylight Saving Time
    strftime(buf, sizeof(buf), "%a %Y-%m-%d %H:%M:%S %Z", ts); // format date and time according to specific conversion rules
    printf("%s\n", buf);

    return 0;
}