//
// The program below takes two arguments: a sleep period in seconds,
// and a timer frequency in nanoseconds.  The program establishes a
// handler for the signal it uses for the timer, blocks that signal,
// creates and arms a timer that expires with the given frequency,
// sleeps for the specified number of seconds, and then unblocks the
// timer signal.  Assuming that the timer expired at least once
// while the program slept, the signal handler will be invoked, and
// the handler displays some information about the timer
// notification.  The program terminates after one invocation of the
// signal handler.
//
// In the following example run, the program sleeps for 1 second,
// after creating a timer that has a frequency of 100 nanoseconds.
// By the time the signal is unblocked and delivered, there have
// been around ten million overruns.
//
// $ ./a.out 1 100
//  Establishing handler for signal 34
//  Blocking signal 34
//  timer ID is 0x804c008
//  Sleeping for 1 seconds
//  Unblocking signal 34
//  Caught signal 34
//      sival_ptr = 0xbfb174f4;     *sival_ptr = 0x804c008
//      overrun count = 10004886
//

#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define CLOCKID CLOCK_REALTIME  // we use CLOCK_REALTIME for our timers
#define SIG SIGRTMIN            // we use signal SIGRTMIN

#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                               } while (0)

static void
print_siginfo(siginfo_t *si)
{
    int      or;
    timer_t  *tidp;

    tidp = si->si_value.sival_ptr;

    printf("    sival_ptr = %p; ", si->si_value.sival_ptr);
    printf("    *sival_ptr = %#jx\n", (uintmax_t) *tidp);

    or = timer_getoverrun(*tidp);
    if (or == -1)
        errExit("timer_getoverrun");
    else
        printf("    overrun count = %d\n", or);
}


static void handler(int sig, siginfo_t *si, void *uc)
{
    /* we use printf() here as a simple way of
       showing that the handler was called. */

    printf("Caught signal %d\n", sig);
    print_siginfo(si);
    signal(sig, SIG_IGN); // This will cause subsequent instances of the signal to be ignored
}

int
main(int argc, char *argv[])
{
    timer_t            timerid;
    sigset_t           mask;
    long long          freq_nanosecs;
    struct sigevent    sev;
    struct sigaction   sa;
    struct itimerspec  its;

    /* we need two arguments when executing our code */
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <sleep-secs> <freq-nanosecs>\n",
                argv[0]);
        exit(EXIT_FAILURE);
    }

    /* Establish handler for timer signal. */
    printf("Establishing handler for signal %d\n", SIG);
    sa.sa_flags = SA_SIGINFO; // indicating that the handler function is pointed by sa_sigaction
    sa.sa_sigaction = handler;
    sigemptyset(&sa.sa_mask); // initialize the blocked signals to be empty
    if (sigaction(SIG, &sa, NULL) == -1) // assigning an action for a signal
        errExit("sigaction");

    /* Block timer signal temporarily. */
    printf("Blocking signal %d\n", SIG);
    sigemptyset(&mask);
    sigaddset(&mask, SIG);
    if (sigprocmask(SIG_SETMASK, &mask, NULL) == -1)
        errExit("sigprocmask");

    /* Create the timer. */
    sev.sigev_notify = SIGEV_SIGNAL;
    sev.sigev_signo = SIG;
    sev.sigev_value.sival_ptr = &timerid; // we pass the time id
    if (timer_create(CLOCKID, &sev, &timerid) == -1)
        errExit("timer_create");

    printf("timer ID is %#jx\n", (uintmax_t) timerid);

    /* Start the timer. */
    freq_nanosecs = atoll(argv[2]);
    its.it_value.tv_sec = freq_nanosecs / 1000000000;
    its.it_value.tv_nsec = freq_nanosecs % 1000000000;
    its.it_interval.tv_sec = its.it_value.tv_sec;
    its.it_interval.tv_nsec = its.it_value.tv_nsec;

    if (timer_settime(timerid, 0, &its, NULL) == -1)
        errExit("timer_settime");

    /* Sleep for a while; meanwhile, the timer may expire
       multiple times. */

    printf("Sleeping for %d seconds\n", atoi(argv[1]));
    sleep(atoi(argv[1]));

    /* Unlock the timer signal, so that timer notification
       can be delivered. */
    printf("Unblocking signal %d\n", SIG);
    if (sigprocmask(SIG_UNBLOCK, &mask, NULL) == -1)
        errExit("sigprocmask");

    exit(EXIT_SUCCESS);
}