#include <sys/time.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>


static sigset_t signal_set;

void wait_next_activation(void)
{
    int dummy;

    sigwait(&signal_set, &dummy);
}

int start_periodic_timer(uint64_t offs, int period)
{
    struct itimerspec t;    // time specifications of the timer
    struct sigevent sigev;  // specifies how to notify when the timer expires
    timer_t timer;
    const int signal = SIGALRM; // signal used for the timer
    int res;

    t.it_value.tv_sec     = offs    / 1000000;
    t.it_value.tv_nsec    = (offs   % 1000000) * 1000;
    t.it_interval.tv_sec  = period  / 1000000;
    t.it_interval.tv_nsec = (period % 1000000) * 1000;

    sigemptyset(&signal_set);       // empty the signal set to initialize it
    sigaddset(&signal_set, signal); // signal to be used is added
    sigprocmask(SIG_BLOCK, &signal_set, NULL); // our signal is blocked

    memset(&sigev, 0, sizeof(struct sigevent)); // initialize sigev
    sigev.sigev_notify = SIGEV_SIGNAL;
    sigev.sigev_signo = signal;
    res = timer_create(CLOCK_MONOTONIC, &sigev, &timer);
    if (res < 0) {
        perror("Timer Create");
    	exit(-1);
    }

    return timer_settime(timer, 0 /*TIMER_ABSTIME*/, &t, NULL);
}

static void job_body(void)
{
    static int cnt;
    static uint64_t start;
    uint64_t t;
    struct timeval tv;

    if (start == 0) {
        gettimeofday(&tv, NULL);
	    start = tv.tv_sec * 1000ULL + tv.tv_usec / 1000ULL;
    }
        
    gettimeofday(&tv, NULL);
    t = tv.tv_sec * 1000ULL + tv.tv_usec / 1000ULL;
    if (cnt && (cnt % 100) == 0) {
        printf("Avg time: %f\n", (double)(t - start) / (double)cnt);
    }
    cnt++;
}

int main()
{
    int res;

    res = start_periodic_timer(2000000, 5000); // offs and period are in microseconds
    if (res < 0) {
        perror("Start Periodic Timer");

        return -1;
    }

    while(1) {
        wait_next_activation();
        job_body();
    }

    return 0;
}
