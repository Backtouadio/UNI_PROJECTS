#include <signal.h>
#include <time.h>
#include <pthread.h>
#include <stdio.h>

#define MY_SIGNAL SIGRTMIN

void do_job(){
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);  /* get current time */
    printf("%lld.%.9ld execution of jobs\n", (long long)ts.tv_sec, ts.tv_nsec);

}

void periodic_thread() /* destined to be the thread */
{
    int signum;                 /* signal caught */
    sigset_t set;               /* signals to be waited for */
    struct sigevent sig;        /* signal information */
    timer_t periodic_timer;     /* timer for a periodic thread */
    struct itimerspec required, old;  /* timer details */
    struct timespec first, period;    /* start and repetition */
    long Thread_Period = 500000000;   /* actual period in nanoseconds */

    /* set up signal interface */
    sig.sigev_notify = SIGEV_SIGNAL;
    sig.sigev_signo = MY_SIGNAL; /* for example */

    /* allow, e.g., 1 sec from now for system initialisation */
    clock_gettime(CLOCK_REALTIME, &first);  /* get current time */
    first.tv_sec = first.tv_sec + 1;
    period.tv_sec = 0;         /* set repetition value to period*/
    period.tv_nsec = Thread_Period;
    required.it_value = first;  /* initialise timer details */
    required.it_interval = period;
    timer_create(CLOCK_REALTIME, &sig, &periodic_timer);

    sigemptyset(&set);         /* initialise signal set to null */
    sigaddset(&set, MY_SIGNAL);  /* only allow timer interrupts*/
    timer_settime(periodic_timer, TIMER_ABSTIME, &required, &old);

    /* enter periodic loop */
    while(1) {
        sigwait(&set, &signum);
        /* code to be executed each period here */
        do_job();
    }
}


int main() {
    pthread_attr_t attributes;      /* thread attributes */
    pthread_t pt;                   /* thread pointer */

    /* Block all real time signals so they can be used for the timers.
       Note: this has to be done in main() before any threads are created
       so they all inherit the same mask. Doing it later is subject to
       race conditions */
    sigset_t alarm_sig;
    sigemptyset(&alarm_sig);
    for (int i = SIGRTMIN; i <= SIGRTMAX; i++)
        sigaddset(&alarm_sig, i);
    sigprocmask(SIG_BLOCK, &alarm_sig, NULL);

    pthread_attr_init(&attributes); /* default attributes */
    pthread_create(&pt, &attributes,
                   (void *) periodic_thread, (void *)0);
    pthread_join(pt,0);
    return 0;
}
