#include <stdio.h>
#include <semaphore.h>
#include <time.h>
#include <errno.h>  // for errno

int main(){

    struct timespec tm; // absolute time specifications for the timeout
    sem_t sem;
    int i=0;
    int r=0;

    sem_init( &sem, 0, 0); // initialize a semaphore with a value of 0

    do {
        clock_gettime(CLOCK_REALTIME, &tm);
        tm.tv_sec += 1;
        i++;
        printf("i=%d\n",i);
        if (i==10) {
            sem_post(&sem);
        }
        r = sem_timedwait( &sem, &tm );
        if(r < 0 && errno ==  ETIMEDOUT) {
            printf("timeout %d reached\n", i);
        };

    } while ( r == -1 );

    printf("Semaphore acquired after %d timeouts\n", i);
    return 0;
}