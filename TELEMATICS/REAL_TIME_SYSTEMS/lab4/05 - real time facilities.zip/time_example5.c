//
// The example program below obtains the CPU-time clock ID of the
// process whose ID is given on the command line, and then uses
// clock_gettime to obtain the time on that clock.  An example
// run is the following:
//
//  $ ./a.out 1                 # Show CPU clock of init process
//  CPU-time clock for PID 1 is 2.213466748 seconds
//

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    clockid_t clockid;
    struct timespec ts;

    if (argc != 2) {
        fprintf(stderr, "%s <process-ID>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if (clock_getcpuclockid(atoi(argv[1]), &clockid) != 0) {
        perror("clock_getcpuclockid");
        exit(EXIT_FAILURE);
    }

    if (clock_gettime(clockid, &ts) == -1) {
        perror("clock_gettime");
        exit(EXIT_FAILURE);
    }

    printf("CPU-time clock for PID %s is %jd.%09ld seconds\n",
           argv[1], (intmax_t) ts.tv_sec, ts.tv_nsec);
    exit(EXIT_SUCCESS);
}